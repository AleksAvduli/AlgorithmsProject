import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.InputMismatchException; // For more specific exception handling

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter the number of dynos: ");
            int numDynos = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character after reading the integer

            System.out.print("Enter the number of possible bonds: ");
            int numPossibleBonds = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            System.out.print("Enter the bucket cost: ");
            int bucketCost = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            System.out.print("Enter the bond cost: ");
            int bondCost = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            List<int[]> bonds = new ArrayList<>();
            System.out.println("Enter the bond pairs (dyno1 dyno2) one per line:");
            for (int i = 0; i < numPossibleBonds; i++) {
                String line = scanner.nextLine();
                String[] bondPairInput = line.split(" ");
                if (bondPairInput.length < 2) {
                    System.err.println("Error: Bond pair line " + (i + 1) + " is not in 'dyno1 dyno2' format. Input was: \"" + line + "\". Please try again or check input.");
                    // You might want to terminate or allow re-entry depending on requirements
                    return;
                }
                int dynoId1 = Integer.parseInt(bondPairInput[0]);
                int dynoId2 = Integer.parseInt(bondPairInput[1]);
                bonds.add(new int[]{dynoId1, dynoId2});
            }

            // Assuming BigWeather.java with calculateMinCostWithKruskal is compiled and accessible
            // This method should be the one from the previous response implementing Kruskal's.
            int minCost = BigWeather.calculateMinCostWithKruskal(numDynos, bonds, bucketCost, bondCost);

            System.out.println("Minimum Cost: " + minCost);

        } catch (InputMismatchException e) {
            System.err.println("Invalid input: Please enter a valid integer where expected.");
            // scanner.nextLine(); // Clear the invalid input
        } catch (NumberFormatException e) {
            System.err.println("Invalid input for bond pair: Please enter numbers for dyno IDs. Details: " + e.getMessage());
        } catch (Exception e) { // Catch-all for other unexpected errors
            System.err.println("An unexpected error occurred: " + e.getMessage());
            e.printStackTrace(); // Helpful for debugging
        } finally {
            scanner.close();
        }
    }
}