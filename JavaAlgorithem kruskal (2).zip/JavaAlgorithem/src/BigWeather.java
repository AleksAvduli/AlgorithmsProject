import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class BigWeather {

    // Edge class for Kruskal's algorithm
    static class Edge implements Comparable<Edge> {
        int u, v; // Node u, Node v
        int weight;
        // String type; // Optional: for debugging, e.g., "bucket" or "bond"

        public Edge(int u, int v, int weight) {
            this.u = u;
            this.v = v;
            this.weight = weight;
        }

        @Override
        public int compareTo(Edge other) {
            return Integer.compare(this.weight, other.weight);
        }

        @Override
        public String toString() {
            return String.format("Edge(%d-%d, w:%d)", u, v, weight);
        }
    }

    // DSU (Disjoint Set Union) class
    static class DSU {
        int[] parent;
        int[] rank; // For union by rank optimization
        // int numComponents; // Can be useful for some graph algorithms

        public DSU(int n) {
            parent = new int[n];
            rank = new int[n];
            // numComponents = n;
            for (int i = 0; i < n; i++) {
                parent[i] = i; // Each element is initially its own parent
                rank[i] = 0;   // Initial rank is 0
            }
        }

        // Finds the representative (root) of the set containing element i
        public int find(int i) {
            if (parent[i] == i) {
                return i;
            }
            // Path compression: make the found root the direct parent of i
            return parent[i] = find(parent[i]);
        }

        // Unites the sets containing elements i and j
        public boolean union(int i, int j) {
            int rootI = find(i);
            int rootJ = find(j);

            if (rootI != rootJ) { // If i and j are in different sets
                // Union by rank: attach the smaller tree under the root of the larger tree
                if (rank[rootI] < rank[rootJ]) {
                    parent[rootI] = rootJ;
                } else if (rank[rootI] > rank[rootJ]) {
                    parent[rootJ] = rootI;
                } else {
                    parent[rootJ] = rootI; // Arbitrarily make rootI the parent
                    rank[rootI]++;         // Increment rank of rootI
                }
                // numComponents--;
                return true; // Union was successful
            }
            return false; // i and j were already in the same set
        }
    }

    /**
     * Calculates the minimum cost to ensure bucket access for all dynos
     * using Kruskal's algorithm on an augmented graph. [cite: 4, 5, 15]
     *
     * @param numDynos The total number of dynos (numbered 1 to N in input). [cite: 25]
     * @param possibleBonds A list of pairs [dyno1, dyno2] representing possible bonds. Dyno IDs are 1-indexed. [cite: 26, 27]
     * @param bucketCost The cost to place a bucket on a dyno. [cite: 25]
     * @param bondCost The cost to form a bond between two dynos. [cite: 25]
     * @return The minimum total cost. [cite: 30]
     */
    public static int calculateMinCostWithKruskal(int numDynos, List<int[]> possibleBonds, int bucketCost, int bondCost) {
        List<Edge> allEdges = new ArrayList<>();

        // Dynos will be 0-indexed internally (0 to numDynos-1).
        // A virtual source node represents the "concept of having a bucket".
        // We'll use 'numDynos' as the ID for this virtual source node (0 to numDynos-1 are actual dynos).
        int virtualSourceNode = numDynos;

        // 1. Add edges representing placing a bucket on a dyno.
        // These connect each actual dyno (0 to numDynos-1) to the virtualSourceNode.
        // The cost of such an edge is the bucketCost.
        for (int i = 0; i < numDynos; i++) {
            allEdges.add(new Edge(i, virtualSourceNode, bucketCost));
        }

        // 2. Add edges representing forming a physical bond between dynos.
        // Dyno IDs in 'possibleBonds' are 1-indexed, so convert them to 0-indexed.
        for (int[] bond : possibleBonds) {
            int u = bond[0] - 1; // Convert dyno ID to 0-indexed
            int v = bond[1] - 1; // Convert dyno ID to 0-indexed
            allEdges.add(new Edge(u, v, bondCost));
        }

        // 3. Sort all potential edges (bucket placements and bonds) by their weight (cost).
        Collections.sort(allEdges);

        // 4. Apply Kruskal's algorithm.
        // The DSU structure will manage numDynos + 1 elements:
        // (0 to numDynos-1 for the actual dynos, and numDynos for the virtual source).
        DSU dsu = new DSU(numDynos + 1);
        int totalMinCost = 0;
        int edgesInMST = 0; // An MST connecting N+1 nodes will have N edges.

        for (Edge edge : allEdges) {
            // If adding this edge does not form a cycle (i.e., u and v are in different sets)
            if (dsu.union(edge.u, edge.v)) {
                totalMinCost += edge.weight; // Add cost of this edge to total
                edgesInMST++;
                // We need to connect all 'numDynos' to the 'virtualSourceNode'.
                // This effectively means forming a spanning tree over the 'numDynos + 1' nodes.
                // Such a tree will have (numDynos + 1) - 1 = numDynos edges.
                if (edgesInMST == numDynos) {
                    break; // MST is complete
                }
            }
        }
        return totalMinCost;
    }

    // The original Dyno class provided within your BigWeather.java.
    // Made static to be potentially accessible if needed elsewhere, similar to Edge and DSU.
    // Not directly used by `calculateMinCostWithKruskal`.
    public static class Dyno {
        int id;
        boolean hasBucket;
        List<Dyno> connectedDynos;

        public Dyno(int id) {
            this.id = id;
            this.hasBucket = false;
            this.connectedDynos = new ArrayList<>();
        }

        public void addConnection(Dyno other) {
            if (!this.connectedDynos.contains(other)) {
                this.connectedDynos.add(other);
            }
        }

        public void removeConnection(Dyno other) {
            this.connectedDynos.remove(other);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Dyno dyno = (Dyno) o;
            return id == dyno.id;
        }

        @Override
        public int hashCode() {
            return Objects.hash(id);
        }
    }

    // This is the original calculateMinCost method from your provided code.
    // It is not used by the Kruskal-based solution.
    // You can rename it or remove it if you are switching to the Kruskal version.
    public static int calculateMinCost(List<Dyno> dynos, int bucketCost, int bondCost) {
        // ... original greedy implementation from your provided file ...
        System.err.println("Warning: The original greedy 'calculateMinCost' method was called.");
        System.err.println("Please use 'calculateMinCostWithKruskal' for the refactored version.");
        // Fallback or throw exception:
        throw new UnsupportedOperationException(
                "This greedy method is not part of the Kruskal refactoring. Use calculateMinCostWithKruskal."
        );
    }

    // This method was part of the setup for your original greedy approach.
    // Not directly used by `calculateMinCostWithKruskal`.
    public static List<Dyno> buildNetwork(int numDynos, List<int[]> bonds) {
        List<Dyno> dynos = new ArrayList<>();
        for (int i = 1; i <= numDynos; i++) {
            dynos.add(new Dyno(i));
        }
        for (int[] bond : bonds) {
            int dynoId1 = bond[0];
            int dynoId2 = bond[1];
            Dyno dyno1 = dynos.get(dynoId1 - 1);
            Dyno dyno2 = dynos.get(dynoId2 - 1);
            dyno1.addConnection(dyno2); // Assumes Dyno.addConnection handles duplicates
            dyno2.addConnection(dyno1);
        }
        return dynos;
    }
}