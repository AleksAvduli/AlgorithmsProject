import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

class Dyno { // This class definition is similar to the inner class in BigWeather.java
    int id;
    boolean hasBucket;
    List<Dyno> connectedDynos;

    public Dyno(int id) {
        this.id = id;
        this.hasBucket = false;
        this.connectedDynos = new ArrayList<>();
    }

    public void addConnection(Dyno otherDyno) {
        // Consider adding a check if the connection already exists to avoid duplicates,
        // though the Kruskal approach doesn't use this Dyno class directly.
        if (!this.connectedDynos.contains(otherDyno)) {
            this.connectedDynos.add(otherDyno);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Dyno dyno = (Dyno) o;
        return id == dyno.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}